function tampilkanSelanjutnya() {
  var teksAwal = document.getElementById("teksAwal");
  var teksSelanjutnya = document.getElementById("teksSelanjutnya");
  var selanjutnya = document.getElementById("selanjutnya");
  var hidetampilanDetail = document.getElementById("hideDetail")
  

  teksAwal.style.display = "none";
  teksSelanjutnya.style.display = "block";
  selanjutnya.style.display = "none";
  hidetampilanDetail.style.display = "block";
}


function tampilkanSelanjutnya1() {
  var teksSelanjutnya1 = document.getElementById("teksSelanjutnya1");
  var selanjutnya1 = document.getElementById("selanjutnya1");
  var hidetampilanDetail1 = document.getElementById("hideDetail1")

  teksSelanjutnya1.style.display = "block";
  selanjutnya1.style.display = "none";
  hidetampilanDetail1.style.display = "block";
}

function hidetampilanDetail() {
  var teksAwal = document.getElementById("teksAwal");
  var teksSelanjutnya = document.getElementById("teksSelanjutnya");
  var selanjutnya = document.getElementById("selanjutnya");
  var hidetampilanDetail = document.getElementById("hideDetail")
  
  teksAwal.style.display = "block";
  teksSelanjutnya.style.display = "none";
  selanjutnya.style.display = "block";
  hidetampilanDetail.style.display = "none";
}
function hidetampilanDetail1() {
  var teksSelanjutnya1 = document.getElementById("teksSelanjutnya1");
  var selanjutnya1 = document.getElementById("selanjutnya1");
  var hidetampilanDetail1 = document.getElementById("hideDetail1")

  teksSelanjutnya1.style.display = "none";
  selanjutnya1.style.display = "block";
  hidetampilanDetail1.style.display = "none";
}
function hidetampilanDetail2() {
  var teksSelanjutnya2 = document.getElementById("teksSelanjutnya2");
  var selanjutnya2 = document.getElementById("selanjutnya2");
  var hidetampilanDetail2 = document.getElementById("hideDetail2")

  teksSelanjutnya2.style.display = "none";
  selanjutnya2.style.display = "block";
  hidetampilanDetail2.style.display = "none";
}

function tampilkanSelanjutnya2() {
  var teksSelanjutnya2 = document.getElementById("teksSelanjutnya2");
  var selanjutnya2 = document.getElementById("selanjutnya2");
  var hidetampilanDetail2 = document.getElementById("hideDetail2")

  teksSelanjutnya2.style.display = "block";
  selanjutnya2.style.display = "none";
  hidetampilanDetail2.style.display = "block";
}